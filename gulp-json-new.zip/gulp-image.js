var gulp = require("gulp");
var spritesmith = require("gulp.spritesmith");
var imagemin = require("gulp-imagemin");
var fs = require("fs");
var log = require('fancy-log');
var jsonImg = JSON.parse(fs.readFileSync("./config/config.json")).images;

/* Change the directory after optimize the image*/

function imageArray(currTask, temp) {
  let files = [];
  let currPath = temp || currTask.srcDir;
  for (var k = 0; k < currTask.srcImg.length; k++) {
    files.push(currPath + currTask.srcImg[k]);
  }
  return files;
}

function minifyImage(currTask, temp) {
  console.log("Image Optimization Started...");
  let files = imageArray(currTask, temp);
  temp = currTask.tempImgDir;
  //console.log("Image Optimization Ended...");
  return new Promise(function(resolve, reject) {
    gulp
      .src(files)
      .pipe(imagemin())
      .pipe(gulp.dest(currTask.tempImgDir))
      .on("end", resolve)
  });
}

function imageSprite(currTask, temp) {
  console.log("ImageSprite Started...");
  let files = imageArray(currTask, temp);
  let spriteData = gulp.src(files).pipe(
    spritesmith({
      imgName: currTask.tempImg,
      cssName: currTask.tempScss
    })
  );
  temp = currTask.tempImgDir;
  console.log("ImageSprite Ended...");
  return new Promise(function(resolve, reject) {
    spriteData.pipe(gulp.dest(currTask.tempImgDir)).on("end", resolve);
  });
}

/* Distribution Function*/

function dist(currTask) {
  console.log("Dist Task Started...");
  console.log(currTask);
  console.log(currTask.tempImgDir + "*.*");
  console.log("Dist Task Ended");
  if (
    fs.access(currTask.tempImgDir, function(error) {
      if (error) {
        console.log("Error");
      } else {
        return gulp
          .src(currTask.tempImgDir + "*.*")
          .pipe(gulp.dest(currTask.dist));
      }
    })
  );
}

/*Call both functions i.e minify_image and image_sprite*/

function imgTask(done) {
  console.log("Image Task Started...");
  var checkArray = jsonImg;
  if (Array.isArray(checkArray) && checkArray.length) {
    for (let i = 0; i < jsonImg.length; i++) {
      let storeObj = jsonImg[i].tasks;
      var currTask = jsonImg[i];
      var temp = "";

      if (storeObj == undefined) {
        console.log("Entered an incorrect task, Please enter a correct task");
      } else {
        if (Array.isArray(storeObj) && storeObj.length) {
          for (var j = 0; j < storeObj.length; j++) {
            let strFunc = storeObj[j];
            if (strFunc == "minifyImage") {
              minifyImage(currTask, temp).then(runDist.bind(null, currTask));
            } else if (strFunc == "imageSprite") {
              imageSprite(currTask, temp).then(runDist.bind(null, currTask));
            }
          }
        }
      }
    }
  }
  function runDist(currTask) {
    console.log("runDist Task Started...");
    console.log(currTask);
    console.log("runDist Task Ended...");
    fs.access(currTask.tempImgDir, function(error) {
      if (error) {
        console.log("Directory does not exist");
      } else {
        dist(currTask);
      }
      done();
    });
  }
  done();
  return;
}

const imageTasks = gulp.series(imgTask);
exports.imageTasks = imageTasks;
