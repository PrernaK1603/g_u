var gulp = require("gulp");
var uglify = require("gulp-uglify");
var concats = require("gulp-concat");
var fs = require("fs");
var jsonJs = JSON.parse(fs.readFileSync("./config/config.json")).js;

var file = "";

function jsArray(currTask, temp) {
  let files = [];
  let currPath = temp || currTask.srcDir;
  if (currPath == temp) {
    fs.readdir(currPath, function(err, items) {
      //console.log("js array dir");
      if (err) {
        console.log("js array dir");
        console.log(err);
      } else {
        console.log(items);
        for (var i = 0; i < items.length; i++) {
          files.push(currPath + items[i]);
        }
      }
    });
  } else {
    for (var k = 0; k < currTask.srcJs.length; k++) {
      files.push(currPath + currTask.srcJs[k]);
    }
  }
  return files;
}

function minifyJs(currTask, temp) {
  console.log("Js Minification Started...");
  let files = jsArray(currTask, temp);
  file = currTask.tempJsDir;
  return new Promise(function(resolve, reject) {
    if (Array.isArray(files) && files.length) {
      console.log(files, "minify");
      gulp
        .src(files)
        .pipe(uglify())
        .pipe(gulp.dest(currTask.tempJsDir))
        .on("end", resolve);
    } else {
      console.log("minify Task not executed");
    }
  });
}

function concateJs(currTask, temp) {
  console.log("Js Concatenation Started...");
  let files = jsArray(currTask, temp);
  file = currTask.tempJsDir;
  return new Promise(function(resolve, reject) {
    if (Array.isArray(files) && files.length) {
      console.log(files, "concate");
      gulp
        .src(files)
        .pipe(concats(currTask.concatejs))
        .pipe(gulp.dest(currTask.tempJsDir))
        .on("end", resolve);
    } else {
      console.log("concate Task not executed");
    }
  });
}

function dist(currTask) {
  console.log("Dist Task Started...");
  if (
    fs.access(currTask.tempJsDir, function(error) {
      if (error) {
        console.log("Error");
      } else {
        return gulp
          .src(currTask.tempJsDir + "*.*")
          .pipe(gulp.dest(currTask.dist));
      }
    })
  );
}

function jsTask(done) {
  console.log("Js Task Started...");
  var checkArray = jsonJs;
  if (Array.isArray(checkArray) && checkArray.length) {
    for (let i = 0; i < jsonJs.length; i++) {
      let storeObj = jsonJs[i].tasks;
      var currTask = jsonJs[i];
      file = "";

      if (storeObj == undefined) {
        console.log("Entered an incorrect task, Please enter a correct task");
      } else {
        if (Array.isArray(storeObj) && storeObj.length) {
          for (var j = 0; j < storeObj.length; j++) {
            let strFunc = storeObj[j];
            if (strFunc == "minifyJs") {
              minifyJs(currTask, file)
                .then(runDist.bind(null, currTask))
            } else if (strFunc == "concateJs") {
              concateJs(currTask, file)
                .then(runDist.bind(null, currTask))
            }
          }
        }
      }
    }
  }
  function runDist(currTask) {
    console.log("runDist Task Started...");
    console.log(currTask);
    console.log("runDist Task Ended...");
    fs.access(currTask.tempJsDir, function(error) {
      if (error) {
        console.log("Directory does not exist");
      } else {
        dist(currTask);
      }
      done();
    });
  }
  done();
  return;
}

const jsTasks = gulp.series(jsTask);
exports.jsTasks = jsTasks;

