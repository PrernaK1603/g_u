var gulp = require("gulp");
var fs = require("fs");
var cheerio = require("gulp-cheerio");
var jsonHtml = JSON.parse(fs.readFileSync("./config/config.json"));

var dom = require("jsdom");
const { JSDOM } = dom;

/*gulp.task("copy-html", function(done) {
  var HTMLContentList = [];
  //var HTMLSubContentList = [];
  for (var i = 0; i < HtmlInputArray.length; i++) {
    dom.JSDOM.fromFile(HtmlInputArray[i].path).then(
      function(config, htmlContentList, d) {
        htmlContentList.push(
          d.window.document.querySelector(config.extractFrom).innerHTML
        );
      }.bind(undefined, HtmlInputArray[i], HTMLContentList)
    );
  }
  dom.JSDOM.fromFile(output)
    .then(
      function(htmlContentList, d) {
        d.window.document.querySelector(
          "body"
        ).innerHTML += htmlContentList.join("\n");
        saveOutput(d.serialize(d.window.document.documentElement.innerHTML));
      }.bind(undefined, HTMLContentList)
    )
    .then(done);
});

function saveOutput(data) {
  fs.writeFile(output, data, function(error) {
    if (error) {
      throw error;
    }
    console.log("Copied portion to output successfully.");
  });
}

gulp.task("include-css-js", function(done) {
  return gulp
    .src("src/index.html")
    .pipe(
      cheerio(function($) {
        $("head").append(
          '<script src="../src/components/header/header.js"></script>'
        );
        $("head").append(
          '<link rel="stylesheet" href="../src/components/body/body.css">'
        );
        $("head").append(
          '<link rel="stylesheet" href="../src/components/header/header.css">'
        );
        $("head").append(
          '<link rel="stylesheet" href="../src/components/footer/footer.css">'
        );
      })
    )
    .pipe(gulp.dest("dest"));
});
*/

/*function htmlTask(done) {
  var htmlContentList = [];
  for (var i = 0; i < jsonHtml.htmlInputArray.length; i++) {
    dom.JSDOM.fromFile(
      jsonHtml.htmlInputArray[i].srcDir + jsonHtml.htmlInputArray[i].srcHtml
    ).then(
      function(config, htmlContentList, d) {
        htmlContentList.push(
          d.window.document.querySelector(config.extractFrom).innerHTML
        );
      }.bind(undefined, jsonHtml.htmlInputArray[i], htmlContentList)
    )
  }
  dom.JSDOM.fromFile(jsonHtml.htmlInputArray[0].tempHtmlDir)
    .then(
      function(htmlContentList, d) {
        d.window.document.querySelector(
          "body"
        ).innerHTML += htmlContentList.join("\n");
        saveOutput(d.serialize(d.window.document.documentElement.innerHTML));
      }.bind(undefined, htmlContentList)
    )
    .then(done);
}

function saveOutput(data) {
  fs.writeFile(jsonHtml.htmlInputArray[0].tempHtmlDir, data, function(error) {
    if (error) {
      throw error;
    }
    console.log("Copied portion to output successfully.");
  });
}*/

function htmlTask(done) {
  var htmlContentList = {};
  for (let i = 0; i < jsonHtml.htmlInputArray.length; i++) {
    dom.JSDOM.fromFile(
      jsonHtml.htmlInputArray[i].srcDir + jsonHtml.htmlInputArray[i].srcHtml
    ).then(
      function(config, htmlContentList, d) {
        htmlContentList[i] = d.window.document.querySelector(
          config.extractFrom
        ).innerHTML;
      }.bind(undefined, jsonHtml.htmlInputArray[i], htmlContentList)
    );
  }
  // console.log(Object.values(htmlContentList));
  dom.JSDOM.fromFile(jsonHtml.htmlInputArray[0].tempHtmlDir)
    .then(
      function(htmlContentList, d) {
        var myContent = "";
        var len = Object.keys(htmlContentList).length;
        for (var key = 0; key < len; key++) {
          myContent += htmlContentList[key];
          console.log({ key, len });
          console.log(myContent);
        }
        d.window.document.querySelector("body").innerHTML += myContent;
        console.log(d.serialize(d.window.document.documentElement.innerHTML));
        saveOutput(d.serialize(d.window.document.documentElement.innerHTML));
      }.bind(undefined, htmlContentList)
    )
    .then(done);
}

function saveOutput(data) {
  fs.writeFile(jsonHtml.htmlInputArray[0].tempHtmlDir, data, function(error) {
    if (error) {
      throw error;
    }
    console.log("Copied portion to output successfully.");
  });
}

function includeCss(done) {
  return gulp
    .src(jsonHtml.htmlInputArray[0].tempHtmlDir)
    .pipe(
      cheerio(function($) {
        $(jsonHtml.htmlInputArray[0].appendCss).append(
          '<script src="../../src/components/header/header.js"></script>'
        );
        $(jsonHtml.htmlInputArray[0].appendCss).append(
          '<link rel="stylesheet" href="../../src/components/body/body.css">'
        );
        $(jsonHtml.htmlInputArray[0].appendCss).append(
          '<link rel="stylesheet" href="../../src/components/header/header.css">'
        );
        $(jsonHtml.htmlInputArray[0].appendCss).append(
          '<link rel="stylesheet" href="../../src/components/footer/footer.css">'
        );
      })
    )
    .pipe(gulp.dest(jsonHtml.htmlInputArray[0].tempHtmlCss));
}

function dist() {
  return gulp
    .src(jsonHtml.htmlInputArray[0].tempHtml)
    .pipe(gulp.dest(jsonHtml.htmlInputArray[0].dist));
}

const htmlTasks = gulp.series(htmlTask, includeCss, dist);
exports.htmlTasks = htmlTasks;
