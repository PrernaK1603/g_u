var gulp = require("gulp");
var jsonMinify = require("gulp-jsonminify");
var fs = require("fs");
var concats = require("gulp-concat");
var Json = JSON.parse(fs.readFileSync("./config/config.json")).json;

function jsonArray(currTask, temp) {
  let files = [];
  let currPath = temp || currTask.srcDir;
  for (var k = 0; k < currTask.srcJson.length; k++) {
    files.push(currPath + currTask.srcJson[k]);
  }
  return files;
}

function minifyJson(currTask, temp) {
  console.log("Json Minification Started...");
  let files = jsonArray(currTask, temp);
  temp = currTask.tempJsonDir;
  console.log("Json Minification Ended...");
  return new Promise(function(resolve, reject) {
    gulp
      .src(files)
      .pipe(jsonMinify())
      .pipe(gulp.dest(currTask.tempJsonDir))
      .on("end", resolve);
  });
}

function concateJson(currTask, temp) {
  console.log("Json Concatenation Started...");
  let files = jsonArray(currTask, temp);
  temp = currTask.tempJsonDir;
  console.log("Json Concatenation Ended...");
  return new Promise(function(resolve, reject) {
    gulp
      .src(files)
      .pipe(concats(currTask.concateJson))
      .pipe(gulp.dest(currTask.tempJsonDir))
      .on("end", resolve);
  });
}

function dist(currTask) {
  console.log("Dist Task Started...");
  console.log(currTask);
  console.log(currTask.tempJsonDir + "*.*");
  console.log("Dist Task Ended...");
  if (
    fs.access(currTask.tempJsonDir, function(error) {
      if (error) {
        console.log("Error");
      } else {
        return gulp
          .src(currTask.tempJsonDir + "*.*")
          .pipe(gulp.dest(currTask.dist));
      }
    })
  );
}

function jsonTask(done) {
  console.log("Json Task Started...");
  var checkArray = Json;
  if (Array.isArray(checkArray) && checkArray.length) {
    for (let i = 0; i < Json.length; i++) {
      let storeObj = Json[i].tasks;
      var currTask = Json[i];
      var temp = "";

      if (storeObj == undefined) {
        console.log("Entered an incorrect task, Please enter a correct task");
      } else {
        if (Array.isArray(storeObj) && storeObj.length) {
          for (var j = 0; j < storeObj.length; j++) {
            let strFunc = storeObj[j];
            if (strFunc == "minifyJson") {
              minifyJson(currTask, temp).then(runDist.bind(null, currTask));
            } else if (strFunc == "concateJson") {
              concateJson(currTask, temp).then(runDist.bind(null, currTask));
            }
          }
        }
      }
    }
  }
  function runDist(currTask) {
    console.log("runDist Task Started...");
    console.log(currTask);
    console.log("runDist Task Ended...");
    fs.access(currTask.tempJsonDir, function(error) {
      if (error) {
        console.log("Directory does not exist");
      } else {
        dist(currTask);
      }
      done();
    });
  }
  done();
  return;
}
const jsonTasks = gulp.series(jsonTask);
exports.jsonTasks = jsonTasks;

//gulp.task("minify_json", json_minify);
