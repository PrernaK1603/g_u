var gulp = require("gulp");
var sass = require("gulp-sass");
var cleanCss = require("gulp-clean-css");
var concatCss = require("gulp-concat");
var fs = require("fs");
var jsonCss = JSON.parse(fs.readFileSync("./config/config.json")).css;

// function scssArray(currTask, temp) {
//   console.log("SCSS ARRAY Started");
//   let files = [];
//   let currPath = temp || currTask.srcDir;
//   console.log(currTask.srcCss);
//   for (var k = 0; k < currTask.srcCss.length; k++) {
//     var fileName = currTask.srcCss[k];
//     var extension = fileName.split(".").pop();
//     if (extension == "scss") {
//       console.log(currPath + currTask.srcCss[k]);
//       files.push(currPath + currTask.srcCss[k]);
//     }
//   }
//   console.log("SCSS ARRAY Ended");
//   return files;
// }

// function scssArray(currTask, temp) {
//   console.log("SCSS ARRAY STARTED");
//   let allFiles = [];
//   let currPath = temp || currTask.srcDir;
//   if (currPath == temp) {
//     fs.readdir("temp/styles", function(err, items) {
//       if (err) {
//         console.log(err);
//       } else {
//         console.log(items);
//         for (var i = 0; i < items.length; i++) {
//           //console.log(items[i]);
//           var fileName = items[i];
//           var extension = fileName.split(".").pop();
//           if (extension == "scss") {
//             allFiles.push(currPath + items[i]);
//           }
//         }
//       }
//     });
//   } else {
//     for (var k = 0; k < currTask.srcCss.length; k++) {
//       var fileName = currTask.srcCss[k];
//       var extension = fileName.split(".").pop();
//       if (extension == "scss") {
//         allFiles.push(currPath + currTask.srcCss[k]);
//       }
//     }
//   }
//   return allFiles;
// }

function directoryExists(currPath){
  return new Promise(function(resolve,reject){
    if(fs.access(currPath,function(error){
      if(error){
        console.log("direc");
      }else{
        resolve('resolved');
      }
    }));
  })
}

function scssArray(currTask, temp) {
  console.log("SCSS ARRAY STARTED");
  let allFiles = [];
  let currPath = temp || currTask.srcDir;
  if (currPath == temp) {
    directoryExists(currPath).then(function(){
      fs.readdir(currPath, function(err, items) {
        if (err) {
          console.log(err);
        } else {
          console.log(items);
          for (var i = 0; i < items.length; i++) {
            var fileName = items[i];
            var extension = fileName.split(".").pop();
            if (extension == "css") {
              allFiles.push(currPath + items[i]);
            }
          }
        }
      })
    }).catch(function(){
      console.log("not  possible");
    })
  } else {
    for (var k = 0; k < currTask.srcCss.length; k++) {
      var fileName = currTask.srcCss[k];
      var extension = fileName.split(".").pop();
      if (extension == "scss") {
        allFiles.push(currPath + currTask.srcCss[k]);
      }
    }
  }
  return allFiles;
}


function cssArray(currTask, temp) {
  console.log("CSS ARRAY STARTED");
  let allFiles = [];
  let currPath = temp || currTask.srcDir;
  if (currPath == temp) {
    directoryExists(currPath).then(function(){
      fs.readdir(currPath, function(err, items) {
        if (err) {
          console.log(err);
        } else {
          console.log(items);
          for (var i = 0; i < items.length; i++) {
            var fileName = items[i];
            var extension = fileName.split(".").pop();
            if (extension == "css") {
              allFiles.push(currPath + items[i]);
            }
          }
        }
      })
    }).catch(function(){
      console.log("not  possible");
    })
  } else {
    for (var k = 0; k < currTask.srcCss.length; k++) {
      var fileName = currTask.srcCss[k];
      var extension = fileName.split(".").pop();
      if (extension == "css") {
        allFiles.push(currPath + currTask.srcCss[k]);
      }
    }
  }
  return allFiles;
}

function exeTask(currTask, task, files) {
  console.log("exeTask started");
  return new Promise(function(resolve, reject) {
    if (Array.isArray(files) && files.length) {
      var g = gulp.src(files);
      if (task == "scssCss") {
        g = g.pipe(sass());
      } else if (task == "minifyCss") {
        g = g.pipe(cleanCss());
      } else if (task == "concateCss") {
        g = g.pipe(concatCss(currTask.concatecss));
      }
      g.pipe(gulp.dest(currTask.tempCssDir)).on("end", resolve);
    } else {
      console.log("*****TASK IS NOT EXECUTED******");
    }
  });
}

function dist(currTask) {
  console.log("In dist...");
  if (
    fs.access("./temp/styles/", function(error) {
      if (error) {
        console.log("Error");
      } else {
        return gulp
          .src(currTask.tempCssDir + "*.*")
          .pipe(gulp.dest(currTask.dist));
      }
    })
  );
}

function cssTask(done) {
  // check for array invalid config
  console.log("cssTask started");
  for (var i = 0; i < jsonCss.length; i++) {
    console.log("*** jsonCss: ", i);
    var storeObj = jsonCss[i].tasks;
    var currTask = jsonCss[i];
    var temp = "";
    if (storeObj == undefined) {
      console.log("Entered an incorrect task, Please enter a correct task");
    } else {
      var files;
      //check for array task
      if (Array.isArray(jsonCss) == true) {
        for (var j = 0; j < storeObj.length; j++) {
          console.log("*** storeObj: ", j);
          console.log("*** storeObj[j]: ", storeObj[j]);
          let strFunc = storeObj[j];
          if (strFunc == "scssCss") {
            files = scssArray(currTask, temp);
          } else if (strFunc == "minifyCss") {
            files = cssArray(currTask, temp);
          } else if (strFunc == "concateCss") {
            files = cssArray(currTask, temp);
          } else {
            console.log("This task does not exist");
            break;
          }
          temp = currTask.tempCssDir;
          exeTask(currTask, strFunc, files).then(runDist.bind(null, currTask));
        }
        console.log("CSS Task ended...");
      }
    }
  }
  function runDist(currTask) {
    console.log("****runDist****");
    console.log(currTask);
    fs.access("./temp/styles/", function(error) {
      if (error) {
        console.log("Directory does not exist");
      } else {
        dist(currTask);
      }
      done();
    });
  }
}

/*
function cssArray(currTask, temp) {
  let files = [];
  let currPath = temp || currTask.srcDir;
  for (var k = 0; k < currTask.srcCss.length; k++) {
    var fileName = currTask.srcCss[k];
    var extension = fileName.split(".").pop();
    if (extension == "css") {
      files.push(currPath + currTask.srcCss[k]);
    }
  }
  return files;
}

function scssArray(currTask, temp) {
  let files = [];
  let currPath = temp || currTask.srcDir;
  for (var k = 0; k < currTask.srcCss.length; k++) {
    var fileName = currTask.srcCss[k];
    var extension = fileName.split(".").pop();
    if (extension == "scss") {
      files.push(currPath + currTask.srcCss[k]);
    }
  }
  return files;
}

function scssCss(currTask, temp) {
  console.log("SCSS to CSS Conversion Started...");
  let files = scssArray(currTask, temp);
  temp = currTask.tempCssDir;
  console.log("SCSS to CSS ended...");
  return new Promise(function(resolve, reject) {
    if (Array.isArray(files) && files.length) {
      gulp
        .src(files)
        .pipe(sass())
        .pipe(gulp.dest(currTask.tempCssDir))
        .on("end", resolve);
    } else {
      gulp.on("error",reject);
    }
  });
}

function minifyCss(currTask, temp) {
  console.log("CSS Minification Started...");
  let files = cssArray(currTask, temp);
  temp = currTask.tempCssDir;
  console.log("CSS Minification ended...");
  return new Promise(function(resolve, reject) {
    if (Array.isArray(files) && files.length) {
      gulp
        .src(files)
        .pipe(cleanCss())
        .pipe(gulp.dest(currTask.tempCssDir))
        .on("end", resolve);
    } else {
        gulp.on("error",reject);
    }
  });
}

function concateCss(currTask, temp) {
  console.log("CSS Concatenation Started");
  let files = cssArray(currTask, temp);
  temp = currTask.tempCssDir;
  console.log("CSS Concatenation Ended...");
  return new Promise(function(resolve, reject) {
    if (Array.isArray(files) && files.length) {
      gulp
        .src(files)
        .pipe(concatCss(currTask.concatecss))
        .pipe(gulp.dest(currTask.tempCssDir))
        .on("end", resolve);
    } else {
        gulp.on("error",reject);
    }
  });
}

function dist(currTask) {
  console.log("Dist Task Started...");
  console.log(currTask);
  console.log(currTask.tempCssDir + "*.*");
  console.log("Dist Task Ended...");
  if (
    fs.access(currTask.tempCssDir, function(error) {
      if (error) {
        console.log("Error");
      } else {
        return gulp
          .src(currTask.tempCssDir + "*.*")
          .pipe(gulp.dest(currTask.dist));
      }
    })
  );
}

function cssTask(done) {
  console.log("CSS Task Started...");
  //var checkArray = jsonCss.css;
  var checkArray=jsonCss;
  if (Array.isArray(checkArray) && checkArray.length) {
    for (let i = 0; i < jsonCss.length; i++) {
      let storeObj = jsonCss[i].tasks;
      var currTask = jsonCss[i];
      var temp = "";

      if (storeObj == undefined) {
        console.log("Entered an incorrect task, Please enter a correct task");
      } else {
        if (Array.isArray(storeObj) && storeObj.length) {
          for (var j = 0; j < storeObj.length; j++) {
            let strFunc = storeObj[j];
            if (strFunc == "concateCss") {
              concateCss(currTask, temp)
                .then(runDist.bind(null, currTask))
                .catch(console.log("CSS Concatenation not possible!"));
            } else if (strFunc == "minifyCss") {
              minifyCss(currTask, temp)
                .then(runDist.bind(null, currTask))
                .catch(console.log("Minification of CSS is not possible!"));
            } else if (strFunc == "scssCss") {
              scssCss(currTask, temp)
                .then(runDist.bind(null, currTask))
                .catch(
                  console.log("Conversion from SCSS to CSS not possible!")
                );
            }
          }
        }
      }
    }
  }
  function runDist(currTask) {
    console.log("runDist Task Started...");
    console.log(currTask);
    fs.access(currTask.tempCssDir, function(error) {
      if (error) {
        console.log("Directory does not exist");
      } else {
        dist(currTask);
      }
      done();
    });
  }
  console.log("CSS Task Ended...");
  done();
  return;
}*/

const cssTasks = gulp.series(cssTask);
exports.cssTasks = cssTasks;
