function show(){
    console.log("data is showed");
}